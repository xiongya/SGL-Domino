# density-code


The file func.R contains all the functions required to run the R codes and DensityCode_QAQC_BaseFamily_Hybrid_Trait.R is build to implement all the models for base family, hybrid and trait along with QAQC. 


The folder Input data contains the data used in the above codes, whereas Output data contains the result obtained from it.

