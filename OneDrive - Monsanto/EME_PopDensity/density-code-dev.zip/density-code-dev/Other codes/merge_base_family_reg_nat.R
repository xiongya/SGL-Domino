rm(list=ls())

setwd("C:/work/proj/density_proj")

den_nat = read.csv('./Output/sample_data_adjusted_Family.csv', stringsAsFactors = F)
den_nat$Geographic = "National"
den_nat$SetGroup = " "
vars = c('Geographic',"SetGroup",'STAGE', 'YEAR', 'SET_RM', 'SET_NAME', 'ANALYSIS_TYPE','TRAIT', 'HYBRID', 'Family', 'POP',
         'ESTIMATE', 'UL_ESTIMATE', 'LL_ESTIMATE','a_intcpt', 'b_pop', 'c_pop_sq', 'd_ye', 'e_ye_pop',"test_pop" , 
         "test_pop_sq","test_ye" , "test_ye_pop", 'R_sq',"site_count", "plot_count", "min_pop","max_pop", "min_yield_level", "max_yield_level" ,
         'ModWarning','OPT_or_NOT','YLD_OPT' , 'LL_YLD_OPT', 'UL_YLD_OPT', 'MAX_YLD',
         'ECO_OPT', 'ECO_YLD', 'SLOPE', 'HD', 'OPT_RANGE', 'YE')

den_reg = read.csv('./Output/sample_data_adjusted_Region_Family.csv', stringsAsFactors = F)
den_reg$Geographic = "Regional"

data_all = rbind(den_nat[,vars], den_reg[,vars]) 
data_all =  data_all[order(data_all$Family),]
library(data.table)
setnames(data_all, "ECO_OPT","ECO_OPT(price = 3.75, cost = 4.5)")
output_path = './Output/'
write.csv(data_all, file = paste(output_path, 'sample_data_nat_reg_Family.csv', sep =''), row.names = F, na ='')
