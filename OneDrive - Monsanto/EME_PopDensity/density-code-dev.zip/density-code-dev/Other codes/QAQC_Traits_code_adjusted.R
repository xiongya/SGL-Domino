#####################
# Loading Libraries #
#####################

#need to link with query

rm(list=ls())

# start.time = Sys.time()

my_pcks = c("MASS","lme4","HLMdiag","car","lsmeans","plyr", "MuMIn","lmerTest","data.table")

lapply(my_pcks,require,character.only=TRUE)

set.seed(726)
#Sys.setlocale('LC_ALL','C') 

setwd("C:/work/proj/density_proj")

source("func.R")

#########################################
# Loading Data and Standardize the Name #
#########################################
#raw data from query
density_yield_data = read.csv('./Density_Yield_Data.csv', stringsAsFactors = F)
density_yield_data$State = as.factor(density_yield_data$SUB_COUNTRY)
density_yield_data$County = as.factor(density_yield_data$SUB_SUB_COUNTRY)
density_yield_data = density_yield_data[,- which(names(density_yield_data) == c("SUB_COUNTRY","SUB_SUB_COUNTRY"))]
#FIPS information
fips_data = read.csv('./FIPS_Data.csv', stringsAsFactors = F)
fips_data$FIPS = as.factor(fips_data$FIPS)
fips_data$State = as.factor(fips_data$State)
fips_data$County = as.factor(fips_data$County)

density_data = merge(density_yield_data,fips_data,by=c("State","County"), all.x= T)
density_data$X=NULL
base_hyb = read.csv('./Base_Family.csv', stringsAsFactors = F)
base_hyb = base_hyb[,c('RM.Group', 'Prod.RM', 'Test.PRODUCT', 'Base')]
colnames(base_hyb) = c('RM.Group', 'Prod.RM', 'HYBRID', 'BASE_HYBRID')

#create variable
#density_data$POP = sapply(density_data$GROUP2, Fun_extpop)

year = unlist(strsplit(as.character(as.Date(density_data$PLANTING_DATE, format="%m/%d/%Y"),"%Y"), '-'))
density_data$YEAR = year
density_data$LOC = paste(density_data$LOC_ID, density_data$FIELD, sep =':')
density_data$POP = density_data$GROUP2/1000

output_path = './Output/'


##################################
#     Pre-defined variables      #
##################################
#Traits in the data
trait_vec = c("YLD","TWT","MST","RTLP","STLP")

#density levels in the data
pop_vec = sort(unique(density_data$POP))

# reasonable range for density
min_den = pop_vec[1]
max_den = pop_vec[length(pop_vec)]

#density to define YE
pop_YE = c(30, 36)

#given a YE, cost, price,  economical optimal
dl_bu = 3.5
dl_1k = 4

density_data$REP_NUMBER = as.factor(density_data$REP_NUMBER)
density_data$IS_ABANDONED = as.logical(density_data$IS_ABANDONED)
density_data$IS_DEACTIVATED = as.logical(density_data$IS_DEACTIVATED)
density_data$IS_RELINQUISHED = as.logical(density_data$IS_RELINQUISHED)

density_pop = density_data[is.na(density_data$HYBRID_PCM_NAME) == F & density_data$IS_DEACTIVATED == F & 
                             density_data$IS_ABANDONED == F & density_data$OBSERVATION_NAME %in% c(trait_vec,"HVPOP"),]

########################
#  Unit Conversion     #
########################
density_pop$VALUE = as.numeric(density_pop$TRAIT_VALUE)

# YLD
#"Quintals/Hectare"  "Bushels(56#)/Acre"
# (bushels/acre) = 1.59311773140035 * (quintals/hectare)
unit_id_yld = which(density_pop$UNIT == "Quintals/Hectare")
density_pop$VALUE[unit_id_yld] =  density_pop$VALUE[unit_id_yld]*1.59311
density_pop$UNIT[unit_id_yld] = "Bushels(56#)/Acre" 

# HVPOP
# "1000 Plants/Hectare" "1000 Plants/Acre" 
# 1 hectare = 2.4710 acres
# 1000 plant/acre = (1000 plant/hectare) /2.4710
unit_id_hvpop = which(density_pop$UNIT == "1000 Plants/Hectare")
density_pop$VALUE[unit_id_hvpop] = density_pop$VALUE[unit_id_hvpop]/2.4710
density_pop$UNIT[unit_id_hvpop] = "1000 Plants/Acre" 


########################
#  Basic QAQC Part     #
########################

#Check the difference between HVPOP and POP
den_hv = density_pop[which(density_pop$OBSERVATION_NAME == 'HVPOP'),]
den_hv$POP_DIFF = abs(den_hv$VALUE - den_hv$POP)

den_hv_all = unique(den_hv[,c('STAGE',  'TEST_SET_NAME','HYBRID_PCM_NAME', 'LOC')])

den_hv_qc = unique(den_hv[den_hv$POP_DIFF <= 3,c('STAGE',  'TEST_SET_NAME','HYBRID_PCM_NAME', 'LOC')])
#Only keep the plots with POP_DIFF less than 3
density_raw = merge(density_pop, den_hv_qc, all.x = F)

qaqc_data = read.csv('./Output/DBFlags.csv', stringsAsFactors = F)
qaqc_data1 = qaqc_data[,c("HYBRID_PCM_NAME", "YEAR", "POP","TEST_SET_NAME", "COUNTRY", "STATE", "COUNTY", 
                           "LOC", "REP_NUMBER","ORIGIN", "SET_RM" , "setgroup" , "BASE_HYBRID" )]
names(qaqc_data1) = c("HYBRID_PCM_NAME", "YEAR", "POP","TEST_SET_NAME", "COUNTRY", "State", "County", 
                       "LOC", "REP_NUMBER","ORIGIN", "SET_RM" , "GEN.Region" , "BASE_HYBRID")

density1 = merge(qaqc_data1, density_raw, by =c("HYBRID_PCM_NAME", "YEAR", "POP","TEST_SET_NAME", "COUNTRY", "State", "County", 
                                                "LOC", "REP_NUMBER","ORIGIN", "SET_RM" , "GEN.Region"))
#Create hybrids ID
# hybrids = data.frame(HYBRID_PCM_NAME = unique(density$HYBRID_PCM_NAME))
hybrids = unique(density1[,c('PRODUCT_NAME','HYBRID_PCM_NAME', 'TEST_SET_NAME')])
hybrids$HYB_ID = 1:nrow(hybrids)
num_hybrid = nrow(hybrids)
# save(hybrids, file = 'our_hyb.RData')
density = merge(density1, hybrids, all.x = F, all.y = F)
####################
#     YLD  part    #
####################
density_yld = density[density$OBSERVATION_NAME == 'YLD',]
# density_yld$YLD_BE = density$VALUE

var_name = c("YEAR",'STAGE',  'PRODUCT_NAME','HYBRID_PCM_NAME',  
             'TEST_SET_NAME', 'LOC', 'REP_NUMBER', 
             'VALUE', 'POP',  'HYB_ID', 'OBSERVATION_NAME',"ORIGIN")

#Final dataset used for future analysis
den_response = density_yld[, var_name]


##################################
#   Modeling and Optimization    #
##################################

#year and stage of the data
stage = paste('PCM', unlist(strsplit(unique(den_response$STAGE), " "))[2], sep = '')
# year = '2016' #change to plant_date year
year = unlist(strsplit(as.character(as.Date(density_pop$PLANTING_DATE[1], format="%m/%d/%Y"),"%Y"), '-'))
trait = 'YLD'
# filename1 = paste(stage, trait, year, 'byHYB', sep ='_')

density_all = den_response
pop_vec = sort(unique(density_all$POP))

min_den = pop_vec[1]
max_den = pop_vec[length(pop_vec)]

#initiate a dataframe to store the output
hybrids_all = NULL

set_list = unique(density_all$TEST_SET_NAME)

hybrids = unique(density_all[, c('PRODUCT_NAME','TEST_SET_NAME', 'HYBRID_PCM_NAME')])
hybrids$HYB_ID = 1:nrow(hybrids)
num_hybrid = nrow(hybrids)

density_all = merge(density_all, hybrids, all.x = F, all.y = F)
setnames(density_all,"VALUE","YIELD")



#Calculate means of the products other than the one of interest for YE
ye_mean = NULL
pb1 = txtProgressBar(0, num_hybrid, 0, style = 3)
for (i in 1:num_hybrid){
  
  d_hyb = density_all[density_all$HYB_ID == i,]
  d_nohyb = density_all[density_all$HYB_ID != i,]
  
  mean_temp = aggregate(d_nohyb$YIELD, list(d_nohyb$LOC, d_nohyb$REP_NUMBER), mean)
  colnames(mean_temp) = c('LOC', 'REP_NUMBER', 'LOC_MEAN')
  mean_temp$HYB_ID = i
  
  ye_mean = rbind(ye_mean, mean_temp)
  setTxtProgressBar(pb1, i)
}
close(pb1)

density_all = merge(density_all, ye_mean, all.x = F, all.y = F)

min_YE = ceiling(min(ye_mean$LOC_MEAN)/10)*10
max_YE = ceiling(max(ye_mean$LOC_MEAN)/10)*10

density_all$POP_SQ = density_all$POP^2
density_all$LOC_MEAN_POP = density_all$LOC_MEAN * density_all$POP
#density_all$LOC_MEAN_POP_SQ = density_all$LOC_MEAN * density_all$POP_SQ


output_all = NULL
#dataset match product name and ID we defined
for (j in 1:length(set_list)){
  # for(j in 1:5){
  set_temp = set_list[j]
  print(paste("Working SET", set_temp, ' '))
  
  density_set = density_all[density_all$TEST_SET_NAME == set_temp, ]
  
  
  var_name = c('YEAR' ,'HYBRID_PCM_NAME', 'LOC', 'REP_NUMBER', 'TEST_SET_NAME', 
               'PRODUCT_NAME', 'ORIGIN','YIELD', 'POP', 
               'POP_SQ', 'LOC_MEAN', 'LOC_MEAN_POP',  'HYB_ID')
  
  #Final dataset used for future analysis
  den_response = density_set[, var_name]
  if(length(unique(den_response$LOC))<3) {next}
  
  ##################################
  #   Modeling and Optimization    #
  ##################################
  
  #initiate a dataframe to store the output
  output_set = NULL
  
  #hybrid list for this set
  hyb_list = sort(unique(den_response$HYB_ID))
  
  print("Calculating Optimal")
  pb = txtProgressBar(0, length(hyb_list),style = 3)
  for (i in hyb_list){
    output = NULL
    t_hyb = i
    
    #filter out data from the particular hybrid
    den_hyb = den_response[which(den_response$HYB_ID == t_hyb),]
    min1 = min(den_hyb$YIELD); max1 = max(den_hyb$YIELD)
    N_LOC = length(unique(den_hyb$LOC))
    N_plot = length(den_hyb$LOC)
    if(N_LOC < 3){next}
    den_hyb$LOC = as.factor(den_hyb$LOC)
    den_hyb$REP_NUMBER = as.factor(den_hyb$REP_NUMBER)
    
    #building the quadratic model: 
    # Y = a + b*POP + c*POP_SQ + d*YE + e*YE*POP
    
    #Full Model
    mod_hyb = lmer(YIELD ~ POP + POP_SQ + LOC_MEAN + LOC_MEAN_POP + (1|LOC), data = den_hyb,
                   REML = T,
                   control = lmerControl(check.scaleX = c("ignore")))
    # cov_reg = vcov(mod_hyb) #covariance matrix of coefficient
    parmt_reg = as.data.frame(t(summary(mod_hyb)$coefficients))
    a = parmt_reg$`(Intercept)`[1]
    b = parmt_reg$POP[1]
    c = parmt_reg$POP_SQ[1]
    d = parmt_reg$LOC_MEAN[1]
    e = parmt_reg$LOC_MEAN_POP[1]
    pval_b = parmt_reg$POP[5]
    pval_c = parmt_reg$POP_SQ[5]
    pval_d = parmt_reg$LOC_MEAN[5]
    pval_e = parmt_reg$LOC_MEAN_POP[5]
    
    #r_2 = as.numeric(r.squaredGLMM(mod_hyb))[2]
    r_2 = 1-var(residuals(mod_hyb))/(var(model.response(model.frame(mod_hyb))))
    adj_r_2 = 1-(1-r_2)*((N_plot-1)/(N_plot-4-1))
    pop_vec = sort(unique(den_hyb$POP))
    
    #simulate data
    sim_locmean = seq(min_YE, max_YE, by = 10) # coeff at all yld environment with diff 10 
    sim_pop = pop_vec
    predsim = expand.grid(sim_locmean, sim_pop )
    colnames(predsim) = c('LOC_MEAN','POP')
    predsim$POP_SQ = predsim$POP ^ 2
    predsim$LOC_MEAN_POP = predsim$LOC_MEAN*predsim$POP
    #predsim$LOC_MEAN_POP_SQ = predsim$LOC_MEAN*predsim$POP_SQ
    predsim$HYBRID_PCM_NAME = hybrids$HYBRID_PCM_NAME[which(hybrids$HYB_ID == t_hyb)]
    
    
    #predictions based on the quadratic model
    #pred_sim = predict(mod_hyb, newdata = predsim, se.fit = T, interval = 'confidence')
    # 
    # pred_fit = as.data.frame(pred_sim$fit)
    # predsim$ESTIMATE = pred_fit$fit
    # predsim$UL_ESTIMATE = pred_fit$upr
    # predsim$LL_ESTIMATE = pred_fit$lwr
    # predsim$STD_ERR = pred_sim$se.fit
    
    predsim$ESTIMATE = a + b*predsim$POP + c*predsim$POP_SQ + d*predsim$LOC_MEAN + e*predsim$LOC_MEAN_POP
    predsim$UL_ESTIMATE = NA
    predsim$LL_ESTIMATE = NA
    predsim$STD_ERR = NA
    #predsim$STD_ERR = pred_sim$se.fit
    
    #sqrt(as.matrix(cbind(1,predsim)) %*% vcov(mod_hyb) %*% t(as.matrix(cbind(1,predsim))))
    
    #yield optimize
    yield_mat =  as.data.frame(t(sapply(as.vector(predsim$LOC_MEAN), Fun_yld_opt)))
    
    predsim$MAX_YLD = unlist(yield_mat$y)
    predsim$YLD_OPT = unlist(yield_mat$x)
    predsim$SLOPE = unlist(yield_mat$slope)
    predsim$OPT_or_NOT = unlist(yield_mat$opt_not)
    predsim$OPT_RANGE = unlist(yield_mat$range)
    
    
    #eco optimize
    eco_mat = as.data.frame(t(sapply(predsim[,'LOC_MEAN'], function(x) Fun_eco_opt(x, dl_bu, dl_1k))))
    predsim$ECO_YLD = unlist(eco_mat$y)
    predsim$ECO_OPT = unlist(eco_mat$x)
    # predsim$MAX_PROFIT = unlist(eco_mat$profit)
    
    predsim$HD = (predsim$SLOPE>1.5) & (predsim$YLD_OPT-35>3)
    
    #formating output
    var_out = c('HYBRID_PCM_NAME', 'LOC_MEAN', 'POP', 
                'ESTIMATE',  'LL_ESTIMATE', 'UL_ESTIMATE',
                'STD_ERR','OPT_or_NOT','YLD_OPT', 'MAX_YLD', 
                'ECO_OPT', 'ECO_YLD', 
                'SLOPE', 'HD', 'OPT_RANGE')
    output = predsim[,var_out]
    
    colnames(output)[1:2] = c('HYBRID','YE')
    output$TRAIT = 'YLD'
    output$EFFECT = paste(output$HYBRID, output$YE, sep = ':')
    output$a_intcpt = a
    output$b_pop = b
    output$c_pop_sq = c
    output$d_ye = d
    output$e_ye_pop = e
    output$test_pop = pval_b
    output$test_pop_sq = pval_c
    output$test_ye = pval_d
    output$test_ye_pop = pval_e
    output$test_ye = pval_d
    output$test_ye_pop = pval_e
    output$min_yield_level = min1
    output$max_yield_level = max1
    output$R_sq = adj_r_2
    output$site_count = N_LOC
    output$plot_count = N_plot
    output$min_pop = min(pop_vec)
    output$max_pop = max(pop_vec) 
    
    setTxtProgressBar(pb, i)
    
    output_set = rbind(output_set, output)
  }
  close(pb)
  
  output_set$SET_NAME = set_temp
  
  output_all = rbind.fill(output_all, output_set)
  
}

output_all$LL_YLD_OPT = ''
output_all$UL_YLD_OPT = ''
output_all$TRAIT = 'YLD'
output_all$ANALYSIS_TYPE = 'CURVE'
output_all$STAGE = 'GENV'
#output_all$YEAR = year
output_all$ModWarning = 'GreenPass'
output_all$ModWarning[output_all$site_count < 5] = 'LowNoLocs'
output_all$ModWarning[output_all$site_count < 5 & output_all$R_sq < 0.6] = 'LowR2&Loc'
output_all$ModWarning[output_all$R_sq < 0.6] = 'LowR2'



# 
# output_all$YLD_OPT = sapply(output_all$YLD_OPT, function(x){
#   if (is.na(x) == F){
#     if (x == max_den) {
#       x = paste('>', max_den, sep = '')
#     } else if (x == min_den){
#       x = paste('<', min_den, sep = '')
#     } else {
#       x = x
#     }
#   } else {x=x}
# })
# 
# output_all$ECO_OPT = sapply(output_all$ECO_OPT, function(x){
#   if (is.na(x)== F){
#     if (x == max_den) {
#       x = paste('>', max_den, sep = '')
#     } else {
#       x = x
#     }
#   } else {x = x}
# 
# })


# var_sort = c( 'TEST_SET_NAME', 'TRAIT', 'ANALYSIS_TYPE', 'HYBRID', 'BASE_HYBRID', 'YE', 'POP',
#               'ESTIMATE', 'UL_ESTIMATE', 'LL_ESTIMATE','STD_ERR', 'a_intcpt', 'b_pop', 'c_pop_sq', 'd_ye', 'e_ye_pop', 'R_sq',
#               'OPT_or_NOT','YLD_OPT' , 'LL_YLD_OPT', 'UL_YLD_OPT', 'MAX_YLD',
#               'ECO_OPT', 'ECO_YLD', 'SLOPE', 'HD', 'OPT_RANGE')
# output_all = output_all[,var_sort]
# 
# output_all$STAGE = stage
#output_all$YEAR = year

data1 = qaqc_data1[,c("HYBRID_PCM_NAME", "YEAR", "POP", "TEST_SET_NAME","COUNTRY","State", "County","ORIGIN", "SET_RM","BASE_HYBRID")]
setnames(data1,c("HYBRID_PCM_NAME","TEST_SET_NAME","BASE_HYBRID"),c("HYBRID","SET_NAME","Family" ) )
output_all1 = merge(output_all, data1, all.x = T)

var_sort = c('STAGE', 'YEAR', 'SET_RM','SET_NAME', 'ANALYSIS_TYPE','TRAIT', 'EFFECT', 'HYBRID', 'Family', 'YE', 'POP',
             'ESTIMATE', 'UL_ESTIMATE', 'LL_ESTIMATE','a_intcpt', 'b_pop', 'c_pop_sq', 'd_ye', 'e_ye_pop',"test_pop" , 
             "test_pop_sq","test_ye" , "test_ye_pop", 'R_sq',"STD_ERR","site_count", "plot_count", "min_pop","max_pop", "min_yield_level", "max_yield_level" ,
             'ModWarning','OPT_or_NOT','YLD_OPT' , 'LL_YLD_OPT', 'UL_YLD_OPT', 'MAX_YLD',
             'ECO_OPT', 'ECO_YLD', 'SLOPE', 'HD', 'OPT_RANGE')


output_all_test = unique(output_all1[,var_sort])
colnames(output_all_test)[colnames(output_all_test) == 'SET_NAME'] = 'TEST_SET_NAME'

output_all_test$Family[is.na(output_all_test$Family)] = substr(output_all_test$HYBRID[is.na(output_all_test$Family)], 1, 6)


# save(output_all, file = './RData/ourdata_pcm4_yld.RData')
# write.csv(output_all, file = paste(filename1, '.csv', sep =''), row.names=F)

########################
# Secondary Trait Part #
########################

lsm_traits = NULL
#compare_traits = NULL

for(t in trait_vec){
  t_analysis  = Fun_lsm1(t)
  lsm_t = t_analysis
  
  lsm_traits = rbind(lsm_traits, lsm_t)
}


#lsm_traits$YEAR = year
lsm_traits$ANALYSIS_TYPE = 'LSMEANS'

colnames(lsm_traits) = c('TRAIT', 'TEST_SET_NAME', 'N_LOC_SET', 'HYBRID', 'POP',
                         'ESTIMATE', 'STD_ERR', 'DF', 'LL_ESTIMATE', 'UL_ESTIMATE', 'ANALYSIS_TYPE' )


dat1 = density1[,c("YEAR","SET_RM","HYBRID_PCM_NAME","POP","OBSERVATION_NAME","TEST_SET_NAME")]
names(dat1) = c("YEAR","SET_RM","HYBRID","POP","TRAIT","TEST_SET_NAME")
lsm_traits1 = merge(lsm_traits, unique(dat1), by=c("HYBRID","POP","TRAIT","TEST_SET_NAME"),all.x = T)
## Merge Base Hybrid Information
#lsm_traits1 = merge(lsm_traits1, base_hyb, all.x = T)


output_alltrait = rbind.fill(output_all_test, lsm_traits1)

#output_alltrait$BASE_HYBRID[is.na(output_alltrait$BASE_HYBRID)] = substr(output_alltrait$HYBRID[is.na(output_alltrait$BASE_HYBRID)], 1, 6)

output_alltrait$HYBRID = as.character(output_alltrait$HYBRID)
output_alltrait$HYBRID = sapply(output_alltrait$HYBRID[1:length(output_alltrait$HYBRID)], function(x){
  if(is.na(hybrids$PRODUCT_NAME[hybrids$HYBRID_PCM_NAME == x]) == T){
    new_name = x
  } else {
    new_name = hybrids$PRODUCT_NAME[hybrids$HYBRID_PCM_NAME == x]  }
})

#output_alltrait$EFFECT[output_alltrait$ANALYSIS_TYPE == 'CURVE'] = paste(output_alltrait$HYBRID[output_alltrait$ANALYSIS_TYPE == 'CURVE'],
#                                                                         output_alltrait$YE[output_alltrait$ANALYSIS_TYPE == 'CURVE'], sep = ':')


output_alltrait$EFFECT[output_alltrait$ANALYSIS_TYPE == 'CURVE'] = paste(output_alltrait$HYBRID[output_alltrait$ANALYSIS_TYPE == 'CURVE'],
                                                                         output_alltrait$YE[output_alltrait$ANALYSIS_TYPE == 'CURVE'], sep = ':')

setnames(output_alltrait,"TEST_SET_NAME","SET_NAME")
output_alltrait = output_alltrait[,c('STAGE', 'YEAR', 'SET_RM','SET_NAME','N_LOC_SET', 'ANALYSIS_TYPE','TRAIT', 'EFFECT', 'HYBRID', 'Family', 'YE', 'POP',
                                    'ESTIMATE', 'UL_ESTIMATE', 'LL_ESTIMATE',"STD_ERR",'a_intcpt', 'b_pop', 'c_pop_sq', 'd_ye', 'e_ye_pop',"test_pop" , 
                                    "test_pop_sq","test_ye" , "test_ye_pop", 'R_sq',"site_count", "plot_count", "min_pop","max_pop", "min_yield_level", "max_yield_level" ,
                                    'ModWarning','OPT_or_NOT','YLD_OPT' , 'LL_YLD_OPT', 'UL_YLD_OPT', 'MAX_YLD',
                                    'ECO_OPT', 'ECO_YLD', 'SLOPE', 'HD', 'OPT_RANGE')]


#Save the output

#filename_all = paste('Trait', '_Density_', year, '_byHYB', sep='')
#write.csv(output_alltrait, file = paste(output_path, filename_all, '.csv', sep =''), row.names=F, na = '')
write.csv(output_alltrait, file = paste(output_path, 'Output_sample_density_fips_trait_adjusted.csv', sep =''), row.names = F, na ='')





