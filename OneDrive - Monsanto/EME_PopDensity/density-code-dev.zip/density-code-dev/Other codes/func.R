##################
#   Function     #
##################


##Fucntion to extract pop(density)##

Fun_extpop = function(track_comment){
  com_split = unlist(strsplit(track_comment, "\\ |\\,| "))
  temp_pop = com_split[2]
  pop = as.numeric(temp_pop)
  return(pop)
}

#extract Studentized Residual for mixed model
StudentResid = function(fit){
  res = residuals(fit)
  # H = hatvalues(fit)
  H = (leverage(fit, level = 1))$overall
  H[which(H>=1)] = 1-.Machine$double.eps
  sigma = summary(fit)$sigm
  sres = sapply(1:length(res), function(i) res[[i]]/(sigma*sqrt(1-H[[i]])))
  return(sres)
}

# calculate yld score for QAQC
Fun_yld_score = function(x){
  if (x<100){
    score = 0.8 + ((100-0.8)/(1+((x/40)^7)))
  }else if (x > 170){
    score = 100 + ((1.5-100)/(1+((x/264)^24)))
  }else {
    score = 0
  }
  return(score)
}

# calculate MST score
Fun_mst_score = function(x){
  if (x < 15){
    score = 0.1 + ((98.3-0.1)/(1+((x/10.3)^14.2)))
  } else if (x > 18){
    score = 95.3 + ((0.01-95.3)/(1+((x/22.2)^41.5)))
  } else {
    score = 0
  }
  return(score)
}

#economical optimal
Fun_eco_opt = function(t_ye, price = 3.75, cost = 4.5){
  #price: sale price, dollar per bushel
  #cost: seed price, dollar per thousand
  b_star = b+e*t_ye
  c_star = c
  a_star = a+d*t_ye
  
  
  #profit = pred_yield*price - pop*cost
  #       = (a+b_star*POP+c_star*POP_SQ)*price - POP*cost
  #       = a*price + (b_star*price - cost)*POP +c_star*price*POP_SQ
  
  x_peak = -(b_star*price - cost)/(2*(c_star*price))
  
  if(c_star < 0){
    if (x_peak > max_den) {
      x_eco = NA
    } else if (x_peak < min_den) {
      x_eco = NA
    } else{
      x_eco = x_peak
    }
    # pr_eco = a*price + (b_star*price - cost)*x_eco +c_star*price*x_eco^2
  } else{
    x_eco = NA
  }
  y_eco = a_star + b_star*x_eco + c_star*x_eco^2
  return(result = list(x = x_eco, y = y_eco
                       #, profit = pr_eco
  ))
}




#Yield Optimal

Fun_yld_opt = function(t_ye){
  b_star = b+e*t_ye
  c_star = c
  a_star = a+d*t_ye
  
  yld_left = a_star + b_star*min_den + c_star*min_den^2
  yld_right = a_star + b_star*max_den + c_star*max_den^2
  
  if(c_star > 0){ #concave up, opt at two end
    slope = NA
    opt_not = 'NO'
    x_max_y = NA
    yld_max = NA
    range = NA
  } else { #concave down, opt at -b*/2c*
    
    x_peak = -b_star/(2*c_star)
    
    if(x_peak > max_den){
      slope = NA
      opt_not = 'NO'
      x_max_y = NA
      yld_max = NA
      range = paste('>',max_den, sep = '')
    } else if(x_peak < min_den){
      slope = NA
      opt_not = 'NO'
      x_max_y = NA
      yld_max = NA
      range = paste('<',min_den, sep = '')
    } else {
      opt_not = 'YES'
      x_max_y = x_peak
      yld_max = a_star + b_star*x_max_y + c_star*x_max_y^2
      slope = abs((yld_max-yld_left)/(max_den-min_den))
      range = 'In Range'
    }
    
  }
  return(result = list(x = x_max_y, y = yld_max, slope = slope, opt_not = opt_not, range = range))
}



### lsmeans trait

Fun_lsm = function(trait){
  print(paste("Working on", trait))
  #subsetting
  den1 = density[density$OBSERVATION_NAME == trait,]
  if (nrow(den1) == 0) next
  
  var_name = c('SET_RM', 'HYBRID_PCM_NAME', 'TEST_SET_NAME', 'LOC', 
               'REP_NUMBER', 'VALUE', 'POP',  'HYB_ID')
  
  #Final dataset used for future analysis
  den_trait_all = den1[, var_name]
  
  lsmeans_trait = NULL
  
  for(j in rm_vec){
    den_rm = den_trait_all[den_trait_all$SET_RM == j,]
    if (nrow(den_rm) == 0) next
    set_name_vec = unique(den_rm$TEST_SET_NAME)
    
    for (n in set_name_vec){
      print(paste('SET_RM =', j, 'SET_NAME =', n))
      den_trait = den_rm[den_rm$TEST_SET_NAME == n,]
      #den_trait$HYB_ID = as.factor(den_trait$HYB_ID)
      
      n_loc_trait_set = length(unique(den_trait$LOC))
      
      # Check how many locations we have and fit model
      if (length(unique(den_trait$LOC)) > 1){
        if (length(unique(den_trait$POP)) < 2 | length(unique(den_trait$HYB_ID)) < 2) next
        mix1 = lmer(VALUE ~ factor(HYB_ID)+POP+factor(HYB_ID)*POP+(1|LOC), data = den_trait,
                    control = lmerControl(check.rankX =  "silent.drop.cols"))
      } else {
        if (length(unique(den_trait$POP)) < 2 | length(unique(den_trait$HYB_ID)) < 2) next
        mix1 = lm(VALUE ~ factor(HYB_ID)+POP+factor(HYB_ID)*POP, data = den_trait)
      } 
      
      lsmeans_set = NULL
      for (p in pop_vec){
        row_limit = nrow(den_trait) +100
        lsm_pop = lsmeans::lsmeans(mix1, pairwise ~ HYB_ID*POP, at = list(POP = p), lsm.options(pbkrtest.limit = row_limit))
        lsmeans_pop = summary(lsm_pop$lsmeans)
        print(paste('Density =', p, 'Finished'))
        
        lsmeans_set = rbind(lsmeans_set, lsmeans_pop)
      }
      
      
      #LSmeans estimate for hyb*pop
      lsmeans_set$SET_RM = j
      lsmeans_set$TEST_SET_NAME = n
      lsmeans_set$N_LOC_SET = n_loc_trait_set
      
      lsmeans_trait = rbind(lsmeans_trait, lsmeans_set)
      
    }
  }
  lsmeans_trait$HYBRID_PCM_NAME = sapply(lsmeans_trait$HYB_ID, function(x){
    hybrids$HYBRID_PCM_NAME[which(hybrids$HYB_ID == x)]
  })
  
  lsmeans_trait$TRAIT = trait
  
  var_sort2 = c('TRAIT', 'SET_RM', 'TEST_SET_NAME', 'N_LOC_SET', 'HYBRID_PCM_NAME', 'POP', 'lsmean', 'SE', 'df',
                'lower.CL', 'upper.CL')
  lsmeans_trait = lsmeans_trait[, var_sort2]
  colnames(lsmeans_trait) = c('TRAIT', 'SET_RM', 'TEST_SET_NAME', 'N_LOC_SET', 'HYBRID','POP',
                              'ESTIMATE', 'STD_ERR', 'DF', 'LL_ESTIMATE', 'UL_ESTIMATE')
  
  return(lsm = lsmeans_trait)
}

################ No Set_rm
Fun_lsm1 = function(trait){
  print(paste("Working on", trait))
  #subsetting
  den1 = density[density$OBSERVATION_NAME == trait,]
  if (nrow(den1) == 0) next
  
  var_name = c( 'HYBRID_PCM_NAME', 'TEST_SET_NAME', 'LOC', 
               'REP_NUMBER', 'VALUE', 'POP',  'HYB_ID')
  
  #Final dataset used for future analysis
  den_trait_all = den1[, var_name]
  
  lsmeans_trait = NULL
  
  #for(j in rm_vec){
    #den_rm = den_trait_all[den_trait_all$SET_RM == j,]
    #if (nrow(den_rm) == 0) next
    set_name_vec = unique(den_trait_all$TEST_SET_NAME)
    
    for (n in set_name_vec){
      print(paste('SET_NAME =', n))
      den_trait = den_trait_all[den_trait_all$TEST_SET_NAME == n,]
      #den_trait$HYB_ID = as.factor(den_trait$HYB_ID)
      
      n_loc_trait_set = length(unique(den_trait$LOC))
      
      # Check how many locations we have and fit model
      if (length(unique(den_trait$LOC)) > 1){
        if (length(unique(den_trait$POP)) < 2 | length(unique(den_trait$HYB_ID)) < 2) next
        mix1 = lmer(VALUE ~ factor(HYB_ID)+POP+factor(HYB_ID)*POP+(1|LOC), data = den_trait,
                    control = lmerControl(check.rankX =  "silent.drop.cols"))
      } else {
        if (length(unique(den_trait$POP)) < 2 | length(unique(den_trait$HYB_ID)) < 2) next
        mix1 = lm(VALUE ~ factor(HYB_ID)+POP+factor(HYB_ID)*POP, data = den_trait)
      } 
      
      lsmeans_set = NULL
      for (p in pop_vec){
        row_limit = nrow(den_trait) +100
        lsm_pop = lsmeans::lsmeans(mix1, pairwise ~ HYB_ID*POP, at = list(POP = p), lsm.options(pbkrtest.limit = row_limit))
        lsmeans_pop = summary(lsm_pop$lsmeans)
        print(paste('Density =', p, 'Finished'))
        
        lsmeans_set = rbind(lsmeans_set, lsmeans_pop)
      }
      
      
      #LSmeans estimate for hyb*pop
      #lsmeans_set$SET_RM = j
      lsmeans_set$TEST_SET_NAME = n
      lsmeans_set$N_LOC_SET = n_loc_trait_set
      
      lsmeans_trait = rbind(lsmeans_trait, lsmeans_set)
      
    }
  
  lsmeans_trait$HYBRID_PCM_NAME = sapply(lsmeans_trait$HYB_ID, function(x){
    hybrids$HYBRID_PCM_NAME[which(hybrids$HYB_ID == x)]
  })
  
  lsmeans_trait$TRAIT = trait
  
  var_sort2 = c('TRAIT', 'TEST_SET_NAME', 'N_LOC_SET', 'HYBRID_PCM_NAME', 'POP', 'lsmean', 'SE', 'df',
                'lower.CL', 'upper.CL')
  lsmeans_trait = lsmeans_trait[, var_sort2]
  colnames(lsmeans_trait) = c('TRAIT',  'TEST_SET_NAME', 'N_LOC_SET', 'HYBRID','POP',
                              'ESTIMATE', 'STD_ERR', 'DF', 'LL_ESTIMATE', 'UL_ESTIMATE')
  
  return(lsm = lsmeans_trait)
}



### lsmeans trait and pair comparison

Fun_lsm_comp = function(trait){
  print(paste("Working on", trait))
  #subsetting
  den1 = density[density$OBSERVATION_NAME == trait,]
  if (nrow(den1) == 0) next
  
  var_name = c('SET_RM', 'HYBRID_PCM_NAME', 'TEST_SET_NAME', 'LOC', 
               'REP_NUMBER', 'VALUE', 'POP',  'HYB_ID')
  
  #Final dataset used for future analysis
  den_trait_all = den1[, var_name]
  
  compare_trait = NULL
  lsmeans_trait = NULL
  
  for(j in rm_vec){
    den_rm = den_trait_all[den_trait_all$SET_RM == j,]
    if (nrow(den_rm) == 0) next
    set_name_vec = unique(den_rm$TEST_SET_NAME)
    
    for (n in set_name_vec){
      print(paste('SET_RM =', j, 'SET_NAME =', n))
      den_trait = den_rm[den_rm$TEST_SET_NAME == n,]
      
      n_loc_trait_set = length(unique(den_trait$LOC))
      
      # Check how many locations we have and fit model
      if (length(unique(den_trait$LOC)) > 1){
        if (length(unique(den_trait$POP)) < 2 | length(unique(den_trait$HYB_ID)) < 2) next
        mix1 = lmer(VALUE ~ as.factor(HYB_ID)+POP+as.factor(HYB_ID)*POP+(1|LOC), data = den_trait,
                    control = lmerControl(check.rankX =  "silent.drop.cols"))
      } else {
        if (length(unique(den_trait$POP)) < 2 | length(unique(den_trait$HYB_ID)) < 2) next
        mix1 = lm(VALUE ~ as.factor(HYB_ID)+POP+as.factor(HYB_ID)*POP, data = den_trait)
      } 
      
      lsmeans_set = NULL
      compare_set = NULL
      for (p in pop_vec){
        row_limit = nrow(den_trait) +100
        lsm_pop = lsmeans(mix1, pairwise ~ HYB_ID*POP, at = list(POP = p),
                          lsm.options(pbkrtest.limit = row_limit))
        compare_pop = summary(lsm_pop$contrasts)
        lsmeans_pop = summary(lsm_pop$lsmeans)
        compare_pop$POP = p
        print(paste('Density =', p, 'Finished'))
        
        lsmeans_set = rbind(lsmeans_set, lsmeans_pop)
        compare_set = rbind(compare_pop, compare_pop)
      }
      
      
      #LSmeans estimate for hyb*pop
      lsmeans_set$SET_RM = j
      lsmeans_set$TEST_SET_NAME = n
      lsmeans_set$N_LOC_SET = n_loc_trait_set
      
      lsmeans_trait = rbind(lsmeans_trait, lsmeans_set)
      
      #Pairwise Comparison
      compare_set$SET_RM = j
      compare_set$TEST_SET_NAME = n
      compare_set$N_LOC_SET = n_loc_trait_set
      
      compare_trait = rbind(compare_trait, compare_set)
    }
  }
  
  compare_trait$p.value = 2*pt(-abs(compare_trait$t.ratio),df=compare_trait$df)
  
  compare_trait$contrast = as.character(compare_trait$contras)
  compare_trait$hyb1 = sapply(compare_trait$contrast, function(x){
    unlist(strsplit(x, "\\ - |\\,| "))[1]
  })
  compare_trait$hyb2 = sapply(compare_trait$contrast, function(x){
    unlist(strsplit(x, "\\ - |\\,| "))[3]
  })
  
  # compare_trait$Sig_or_Not = compare_trait$p.value<0.05
  compare_trait$PRODUCT1 = sapply(compare_trait$hyb1, function(x){
    hybrids$HYBRID_PCM_NAME[which(hybrids$HYB_ID == x)]
  })
  compare_trait$PRODUCT2 = sapply(compare_trait$hyb2, function(x){
    hybrids$HYBRID_PCM_NAME[which(hybrids$HYB_ID == x)]
  })
  
  
  lsmeans_trait$HYBRID_PCM_NAME = sapply(lsmeans_trait$HYB_ID, function(x){
    hybrids$HYBRID_PCM_NAME[which(hybrids$HYB_ID == x)]
  })
  
  lsmeans_trait$TRAIT = trait
  compare_trait$TRAIT = trait
  
  
  var_sort1 = c('TRAIT', 'SET_RM', 'TEST_SET_NAME', 'N_LOC_SET', 'PRODUCT1', 'PRODUCT2', 'POP', 'estimate', 
                'SE', 'df', 't.ratio', 'p.value')
  output_compare = compare_trait[, var_sort1]
  colnames(output_compare) = c('TRAIT', 'SET_RM', 'TEST_SET_NAME', 'N_LOC_SET', 'HYBRID1', 'HYBRID2', 'POP', 'ESTIMATE',
                               'STD_ERR', 'df', 't.ratio', 'p.value')
  
  
  var_sort2 = c('TRAIT', 'SET_RM', 'TEST_SET_NAME', 'N_LOC_SET', 'HYBRID_PCM_NAME', 'POP', 'lsmean', 'SE', 'df',
                'lower.CL', 'upper.CL')
  lsmeans_trait = lsmeans_trait[, var_sort2]
  colnames(lsmeans_trait) = c('TRAIT', 'SET_RM', 'TEST_SET_NAME', 'N_LOC_SET', 'HYBRID','POP',
                              'ESTIMATE', 'STD_ERR', 'DF', 'LL_ESTIMATE', 'UL_ESTIMATE')
  
  return(list(compare = output_compare, lsm = lsmeans_trait))
}


