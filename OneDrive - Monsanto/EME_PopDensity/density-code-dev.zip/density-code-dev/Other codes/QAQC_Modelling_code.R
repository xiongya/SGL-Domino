#####################
# Loading Libraries #
#####################

#need to link with query
#Reading data in line 156 and output at bottom

rm(list=ls())

# start.time = Sys.time()

my_pcks = c("MASS","lme4","HLMdiag","car","lsmeans","plyr", "MuMIn","lmerTest","data.table")

lapply(my_pcks,require,character.only=TRUE)

set.seed(726)
#Sys.setlocale('LC_ALL','C') 

setwd("C:/work/proj/density_proj")
source("func.R")

#raw data from query
#raw data from query
density_yield_data = read.csv('./Density_Yield_Data.csv', stringsAsFactors = F)
density_yield_data$State = as.factor(density_yield_data$SUB_COUNTRY)
density_yield_data$County = as.factor(density_yield_data$SUB_SUB_COUNTRY)
density_yield_data = density_yield_data[,- which(names(density_yield_data) == c("SUB_COUNTRY","SUB_SUB_COUNTRY"))]
#FIPS information
fips_data = read.csv('./FIPS_Data.csv', stringsAsFactors = F)
fips_data$FIPS = as.factor(fips_data$FIPS)
fips_data$State = as.factor(fips_data$State)
fips_data$County = as.factor(fips_data$County)

genv_query = merge(density_yield_data,fips_data,by=c("State","County"), all.x= T)
genv_query$X=NULL
#genv_query = genv_query[which(genv_query$Year == "2015" | genv_query$Year == "2016"),]

output_path = './Output/'


#########################################
# Loading Data and Standardize the Name #
#########################################

base_hyb = read.csv('./Base_Family.csv', stringsAsFactors = F)
base_hyb = base_hyb[, c("Test.PRODUCT", "Base")]
colnames(base_hyb) = c('HYBRID', 'BASE_HYBRID')

# variables = c("YEAR" , "TEST_SET_NAME","SET_RM","FIELD", "PLANTING_DATE", "HARVEST_DATE",  "IS_IRRIGATED", "Tillage.Method",   "Previous.Crop",  "REP_NUMBER","IS_ABANDONED",             
#                          "IS_DEACTIVATED","Deactivation.Reason","IS_RELINQUISHED" , "BASE_HYBRID", "ORIGIN","PRODUCT_NAME","HYBRID_PCM_NAME",  "Seed.Trait.Name" ,       
#                          "Plot.BID" ,  "GROUP1","GROUP2" , "Absolute.Column",  "Absolute.Range",  "COUNTRY","State" , "County",  "FIPS",  "Lat.1",                  
#                          "Long.1" ,  "Lat.2" ,"Long.2" , "Lat.3" , "Long.3",  "Lat.4", "Long.4", "OBSERVATION_NAME", "UNIT","TRAIT_VALUE", "Test.Weight",  "Shell.Weight",
#                          "Final.Stand.Percent" , "Total.Greensnap.Percent", "Percent.Stalk.Lodging",   "Root.Lodged.Percent" , "LOC_ID" )


genv_query$IS_IRRIGATED= as.logical(genv_query$IS_IRRIGATED)
genv_query$IS_DEACTIVATED = as.logical(genv_query$IS_DEACTIVATED)
genv_query$IS_RELINQUISHED = as.logical(genv_query$IS_RELINQUISHED)

genv_raw = genv_query[genv_query$OBSERVATION_NAME %in% c('YLD', 'HVPOP', 'MST') &
                        genv_query$IS_ABANDONED == F & genv_query$IS_DEACTIVATED == F & genv_query$IS_RELINQUISHED == T,]

#genv_raw = genv_query[genv_query$IS_ABANDONED == F & genv_query$IS_DEACTIVATED == F & genv_query$IS_RELINQUISHED == T,]
# 
# genv_raw = genv_query[genv_query$OBSERVATION_NAME %in% c('YLD', 'HVPOP','MST') &
#                         genv_query$IS_ABANDONED == F & genv_query$IS_DEACTIVATED == F,]


year = unlist(strsplit(as.character(as.Date(genv_raw$PLANTING_DATE, format="%m/%d/%Y"),"%Y"), '-'))
genv_raw$YEAR = year
genv_raw$LOC = paste(genv_raw$LOC_ID, genv_raw$FIELD, sep =':')
genv_raw$POP = genv_raw$GROUP2/1000

########################
#  Unit Conversion     #
########################
genv_raw$TRAIT_VALUE = as.numeric(genv_raw$TRAIT_VALUE)

# YLD
#"Quintals/Hectare"  "Bushels(56#)/Acre"
# (bushels/acre) = 1.59311773140035 * (quintals/hectare)
unit_id_yld = which(genv_raw$UNIT == "Quintals/Hectare")
genv_raw$TRAIT_VALUE[unit_id_yld] =  genv_raw$TRAIT_VALUE[unit_id_yld]*1.59311
genv_raw$UNIT[unit_id_yld] = "Bushels(56#)/Acre" 

# HVPOP
# "1000 Plants/Hectare" "1000 Plants/Acre" 
# 1 hectare = 2.4710 acres
# 1000 plant/acre = (1000 plant/hectare) /2.4710
unit_id_hvpop = which(genv_raw$UNIT == "1000 Plants/Hectare")
genv_raw$TRAIT_VALUE[unit_id_hvpop] = genv_raw$TRAIT_VALUE[unit_id_hvpop]/2.4710
genv_raw$UNIT[unit_id_hvpop] = "1000 Plants/Acre" 

#Checking HVPOP for QAQC purpose
genv_hv = genv_raw[genv_raw$OBSERVATION_NAME == 'HVPOP',]
genv_hv$POP_DIFF = abs(genv_hv$TRAIT_VALUE - genv_hv$POP)
# genv_hv_qc = unique(genv_hv[genv_hv$POP_DIFF<3, c( 'TEST_SET_NAME','HYBRID_PCM_NAME', 'LOC', 'REP_NUMBER')])
# genv_hv_no = unique(genv_hv[, c('TEST_SET_NAME','HYBRID_PCM_NAME', 'LOC', 'REP_NUMBER')])
genv_hv_del = unique(genv_hv[genv_hv$POP_DIFF > 3, c('TEST_SET_NAME', 'HYBRID_PCM_NAME', 'LOC', 'REP_NUMBER')])

#Merge MST Information
genv_yld = genv_raw[genv_raw$OBSERVATION_NAME == 'YLD',]

genv_mst = genv_raw[genv_raw$OBSERVATION_NAME == 'MST',]
genv_mst$MST = genv_mst$TRAIT_VALUE
genv_mst$OBSERVATION_NAME = NULL
genv_mst$UNIT = NULL
genv_mst$TRAIT_VALUE = NULL

genv_yld_mst = merge(genv_yld, genv_mst)

#Only keep the plots with POP_DIFF less than 3
genv_yld_del = merge(genv_yld_mst, genv_hv_del, all.x=F) 
temp = rbind(genv_yld_mst, genv_yld_del)
genv_yld1 = temp [!duplicated(temp ,fromLast = FALSE)&!duplicated(temp ,fromLast = TRUE),] 

#genv_yld1 = genv_hv[which(genv_hv$POP_DIFF < 3),] 


# Fixing names and keep useful columns
var_use = c('YEAR', 'FIPS',  'TEST_SET_NAME', 'LOC', 'REP_NUMBER', 'ORIGIN',
            'PRODUCT_NAME', 'HYBRID_PCM_NAME', 'POP','COUNTRY', 'State','County', 
            'OBSERVATION_NAME', 'UNIT','TRAIT_VALUE', 'MST')
genv_data = genv_yld1[,var_use]


colnames(genv_data) = c('season', 'FIPS', 'set', 'field', 'block', 
                        'origin', 'product_name', 'hybrid', 
                        'pop', 'country', 'state', 'county',
                        'trait', 'unit', 'YLD', 'MST')


# region_data = region_data[,c('statef', 'countyf', 'FIPS', 'setgroup', 'region')]

########################
# Data Cleaning:       #
########################

# remove missing values

yld_data = genv_data[which(is.na(genv_data$YLD) == F 
                           & is.na(genv_data$pop) == F
                           & is.na(genv_data$hybrid) == F
                           & genv_data$hybrid != ''),]


#write.csv(yld_data1, file = paste(output_path, 'gen_data_new.csv', sep =''), row.names = F, na ='')
##############
# First QC:  #
##############
# Using Basic model and extract DF and resids 
# figure out extreme values at field level by hybs
yld_data$locyr = paste(yld_data$season, yld_data$field, sep =':')
yld_data = yld_data[order(yld_data$locyr,  yld_data$set, yld_data$hybrid),]
yld_data$temp_id = paste(yld_data$locyr,  yld_data$set, yld_data$hybrid)
yld_data$temp_id = as.numeric(as.factor(yld_data$temp_id))

yld_data1 = yld_data

# save(yld_data, file = './RData/yld_data.RData')

case_id = unique(yld_data1$temp_id)

#yld_data1$DF = 0
yld_data1$Pred = 0
yld_data1$Resid = Inf
yld_data1$StudResid = Inf

options(warn = 2)#Turn all warnings into error
pb = txtProgressBar(0, max(yld_data1$temp_id), 0, style = 3)
for (i in case_id){
  dt_index = which(yld_data1$temp_id == i)
  dt = yld_data1[dt_index,]
  
  # mt_try = lmer(YLD ~ as.factor(pop) + (1|block), data = dt)
  
  mt_try <- try(lmer(YLD ~ as.factor(pop) + (1|block), data = dt, REML = TRUE, control = lmerControl()), TRUE)
  if(inherits(mt_try, "try-error"))
  {
    #error handling code, maybe just skip this iteration using
    next
  }
  #rest of iteration for case of no error
  #aov_try = aov(YLD ~ as.factor(pop) + as.factor(block), data = dt)
  #df = aov_try$df.residual
  pred = fitted(mt_try)
  res = resid(mt_try)
  #sres = StudentResid(mt_try)
  
  #yld_data1$DF[dt_index] = df
  yld_data1$Pred[dt_index] = pred
  yld_data1$Resid[dt_index] = res
  # 
  sres_try = try(StudentResid(mt_try), TRUE)
  if(inherits(sres_try, "try-error")){
    sres = NA
  }else{sres = sres_try}
  yld_data1$StudResid[dt_index] = sres
  
  setTxtProgressBar(pb, i)
  #print(i)
}
close(pb)
# save(yld_data1, file = './RData/yld_data1.RData')

options(warn = 0)#Change warning settings back to defualt

#Remove extreme values
yld_data2 = yld_data1[which(abs(yld_data1$Resid) < 50 &
                              abs(yld_data1$StudResid) < 3.5 ),
                      c('season', 'FIPS',  'set', 'field', 'block', 'locyr',
                        'origin', 'product_name', 'hybrid', 
                        'pop', 'country', 'state', 'county',
                        'trait', 'unit', 'YLD', 'MST', 'temp_id')]



####################
# Calculating YE:  #
####################
yld_data3 = yld_data2

yld_data3 = yld_data3[order(yld_data3$season, yld_data3$set, yld_data3$hybrid),]
yld_data3 = yld_data3[, !names(yld_data3) %in% c('temp_id','size')]

hybrid_mean = aggregate(yld_data3$YLD, list(yld_data3$season, yld_data3$set, yld_data3$hybrid), mean)
colnames(hybrid_mean) = c('season', 'set', 'hybrid', 'mean')
hybrid_mean$count = 1:nrow(hybrid_mean)

#Total number of models
total_mod = nrow(hybrid_mean)


#Calculate means of the products other than the one of interest for YE
ye_mean = NULL
pb1 = txtProgressBar(0, total_mod, 0, style = 3)
for (i in 1:total_mod){
  case = hybrid_mean[i,]
  s = case[,1]
  # stg = case[,2]
  st = case[,2]
  hyb = case[,3]
  d_stg = yld_data3[which(yld_data3$season == s & yld_data3$set == st),]
  
  d_hyb = d_stg[d_stg$hybrid == hyb,]
  d_nohyb = d_stg[d_stg$hybrid != hyb,]
  
  mean_temp = aggregate(d_nohyb$YLD, list(d_nohyb$field, d_nohyb$block), mean)
  colnames(mean_temp) = c('field', 'block', 'ye')
  mean_temp$hybrid = hyb
  mean_temp$season = s
  #mean_temp$set_rm = stg
  mean_temp$set = st
  ye_mean = rbind(ye_mean, mean_temp)
  setTxtProgressBar(pb1, i)
}
close(pb1)


yld_final = merge(yld_data3, ye_mean)
# save(yld_final, file = './RData/yld_final.RData')

################################
# QC 2: Diagnostic and Data QC #
################################
yld_final = yld_final[which(is.na(yld_final$ye)== F & is.na(yld_final$YLD)== F),]

#sort and create ordered id
yld_final = yld_final[order(yld_final$locyr,  yld_final$set, yld_final$hybrid,
                            yld_final$block),]
yld_final$obs_id = 1:nrow(yld_final)

yld_data4 = yld_final
yld_data4$temp_id = paste(yld_data4$season,  yld_data4$set, yld_data4$hybrid)
yld_data4$temp_id = as.numeric(as.factor(yld_data4$temp_id))


#Data QC Procedure
#fit surface model to estract residuals by hybrid

yld_data4$Predicted = 0
yld_data4$Residual = 0
yld_data4$Stud_Resid = 0
yld_data4$Press_Resid = 0
yld_data4$CookD = 0
yld_data4$Cov_Ratio = 0
yld_data4$Leverage = 0
yld_data4$Nobs_Used = 0

pb3 = txtProgressBar(0, max(yld_data4$temp_id), 0, style = 3)
for(i in 1:max(yld_data4$temp_id)){
  #fitting model
  dt_index = which(yld_data4$temp_id == i)
  dt = yld_data4[dt_index,]
  dt$pop_sq = dt$pop^2
  dt$ye_sq = dt$ye^2
  dt$pop_ye = dt$pop*dt$ye
  mt = lm(YLD ~ pop + pop_sq + ye + pop_ye, data = dt)
  
  #extract prediction and residuals
  nobs = nrow(dt)
  pred = mt$fitted.values
  res = mt$residuals
  sres = studres(mt)
  leverage = influence(mt)$hat
  #press = PRESS(mt, verbose = F)$residuals
  pr <- res/(1-leverage)
  #' calculate the PRESS
  press <- sum(pr^2)
  cookd = cooks.distance(mt)
  covr = stats::covratio(mt)
  
  yld_data4$Predicted[dt_index] = pred
  yld_data4$Residual[dt_index] = res
  yld_data4$Stud_Resid[dt_index] = sres
  yld_data4$Press_Resid[dt_index] = press
  yld_data4$CookD[dt_index] = cookd
  yld_data4$Leverage[dt_index] = leverage
  yld_data4$Cov_Ratio[dt_index] = covr
  yld_data4$Nobs_Used[dt_index] = nobs
  
  setTxtProgressBar(pb3, i)
}
close(pb3)

# save(yld_data4, file = './RData/yld_data.RData')

#computing average yield per rep
rep_mean = aggregate(yld_data4$YLD, list(yld_data4$locyr, yld_data4$set, yld_data4$block)
                     ,FUN = function(x) c(RepYield = mean(x), CV = sd(x)/mean(x)*100))
rep_mean$rep_yld = unlist(rep_mean$x)[,1]
rep_mean$cv = unlist(rep_mean$x)[,2]
rep_mean = rep_mean[,-4]
colnames(rep_mean) = c('locyr', 'set', 'block', 'rep_yld', 'rep_cv')

yld_diag = merge(yld_data4, rep_mean)

#Creating QC statistics

yld_diag$devfromrep = (abs(yld_diag$rep_yld-yld_diag$YLD)/yld_diag$rep_yld)*100
yld_diag$devfromcv = (yld_diag$devfromrep - 2*yld_diag$rep_cv)
yld_diag$devfromcv[which(yld_diag$devfromcv < 0)] = 0


yld_diag$yld_score = sapply(yld_diag$YLD, Fun_yld_score)
yld_diag$mst_score = sapply(yld_diag$MST, Fun_mst_score)
yld_diag$rep_score = 100 + ((0.5-100)/(1+((yld_diag$devfromcv/13)^10)))
yld_diag$repcv_score = 100 + ((0.5-100)/(1+((yld_diag$rep_cv/25)^3.9)))
yld_diag$repcv_flag = 'Greenpass'
yld_diag$repcv_flag[yld_diag$repcv_score > 70] = 'Yellow'
yld_diag$repcv_flag[yld_diag$repcv_score > 80] = 'Red'

yld_diag$absres = abs(yld_diag$Residual)
yld_diag$res_score = 100 + ((1.8-100)/(1+((yld_diag$absres/60)^7.7)))

yld_diag$abspress = abs(yld_diag$Press_Resid)
yld_diag$press_score = 100 + ((1.8-100)/(1+((yld_diag$abspress/60)^7.7)))

yld_diag$absstu = abs(yld_diag$Stud_Resid)
yld_diag$stu_score = 98 + ((0.1-98)/(1+((yld_diag$absstu/2)^15.4)))

yld_diag$gamma_lev = 14.6*(yld_diag$Nobs_Used^(-0.9))
yld_diag$lev_score = 100 + ((2.3-100)/(1+((yld_diag$Leverage/yld_diag$gamma_lev)^8)))

yld_diag$gamma_cook = 2.3*(yld_diag$Nobs_Used^(-0.53))
yld_diag$cook_score = 100+((2.3-100)/(1+((yld_diag$CookD/yld_diag$gamma_cook)^7)))


yld_diag$gamma_cov = 20.7*(yld_diag$Nobs_Used^(-0.85))
yld_diag$covminus1 = abs(yld_diag$Cov_Ratio - 1)
yld_diag$cov_score = 99 + ((2.5-99)/(1+((yld_diag$covminus1/yld_diag$gamma_cov)^14.5)))

#Agronomics Penalization
yld_diag$ag_pen = 0.4*(yld_diag$yld_score) + 0.4*(yld_diag$mst_score) + 0.2*(yld_diag$rep_score)
yld_diag$ag_flag = 'Greenpass'
yld_diag$ag_flag[yld_diag$ag_pen > 50] = 'Yellow'
yld_diag$ag_flag[yld_diag$ag_pen > 60] = 'Red'

#Influence in Parameter Estimation
yld_diag$par_pen = 0.4*yld_diag$lev_score + 0.6*yld_diag$cook_score
yld_diag$par_flag = 'Greenpass'
yld_diag$par_flag[yld_diag$par_pen > 75] = 'Yellow'
yld_diag$par_flag[yld_diag$par_pen > 85] = 'Red'
yld_diag$par_flag[yld_diag$lev_score > 95 | yld_diag$cook_score > 95] = 'Red'


#Influence in Precision
yld_diag$acc_pen = yld_diag$cov_score
yld_diag$acc_flag = 'Greenpass'
yld_diag$acc_flag[yld_diag$acc_pen > 85] = 'Yellow'
yld_diag$acc_flag[yld_diag$acc_pen > 95] = 'Red'

#Influence in Predicted Values
yld_diag$pre_pen = 0.2*yld_diag$res_score + 0.5*yld_diag$press_score + 0.3*yld_diag$stu_score
yld_diag$pre_flag = 'Greenpass'
yld_diag$pre_flag[yld_diag$pre_pen > 80] = 'Yellow'
yld_diag$pre_flag[yld_diag$pre_pen > 90] = 'Red'
yld_diag$pre_flag[yld_diag$res_score>95 | yld_diag$press_score>95 | yld_diag$stu_score >95] = 'Red'

#Modeling Penalization
yld_diag$mod_pen = 0.45*yld_diag$par_pen + 0.1*yld_diag$acc_pen + 0.45*yld_diag$pre_pen
yld_diag$mod_flag = 'Greenpass'
yld_diag$mod_flag[yld_diag$mod_pen > 50] = 'Yellow'
yld_diag$mod_flag[yld_diag$mod_pen > 60] = 'Red'


#Weighted Score
yld_diag$w_pen = 0.35*yld_diag$ag_pen + 0.65*yld_diag$mod_pen
yld_diag$w_flag = 'Greenpass'
yld_diag$w_flag[yld_diag$w_pen > 35] = 'Yellow'
yld_diag$w_flag[yld_diag$w_pen > 45] = 'Red'

# save(yld_diag, file = paste(deployFolder,"/models/yld_diag.RData", sep=""))

#Extracting All Extreme Observations


#extreme_ag = yld_diag[which(yld_diag$ag_flag == 'Yellow' | yld_diag$ag_flag == 'Red'), ]
#extreme_mod = yld_diag[which(yld_diag$mod_flag == 'Yellow' | yld_diag$mod_flag == 'Red'), ]
#outliers_w = yld_diag[which(yld_diag$w_flag == 'Yellow' | yld_diag$w_flag == 'Red'), ]

# 
# end.time = Sys.time()
# end.time - start.time

#write.csv(yld_diag, file = paste(output_path, 'Output_QAQC.csv', sep =''), row.names = F, na ='')

var_mod = c('season', 'FIPS', 'locyr', 'set', 'field', 'block', 
            'origin', 'product_name', 'hybrid', 
            'pop', 'country', 'state', 'county',
            'trait', 'unit', 'YLD', 'MST','ye','rep_cv','devfromrep', 'devfromcv','w_pen','w_flag')

den_raw = yld_diag[which(yld_diag$w_flag != 'Red' & 
                           yld_diag$ag_flag != 'Red' & 
                           yld_diag$mod_flag != 'Red'), var_mod]

data1 = den_raw[order(den_raw$season, den_raw$set, den_raw$hybrid), ]
data1$temp_id = paste(data1$season, data1$set, data1$hybrid)
data1$temp_id = as.numeric(as.factor(data1$temp_id))

yld_1 = data1  
unique_id = unique(yld_1$temp_id)
#yld_data = NULL
d1 = NULL
for (i in unique_id){
  #i=i+1
  dt_index = which(yld_1$temp_id == i)
  dt = yld_1[dt_index,]
  Loc_N = length(unique(dt$field))
  rep_N = length(unique(dt$block))
  
  density_data = count(dt[, c('season', 'set','hybrid', 'pop')])
  setnames(density_data, "freq", "N_pop" )
  len_pop = length(unique(density_data$pop))
  #if(len_pop > 3){next}
  dat1 = as.numeric(density_data$N_pop >= floor(0.7*Loc_N*rep_N))
  #print(dat1)
  if(min(dat1)==0 || len_pop < 3){
    yld_1 = yld_1[-dt_index,]
  }else{yld_1 = yld_1}
  d1 = c(d1,dim(dt)[1])
  #print(c(i,dim(yld_1)))
  #yld_data = rbind(yld_data,yld_1)  
}


density_all1 = yld_1[,c("season", "FIPS", "locyr","set", "field", "block",
                        "origin", "product_name", "hybrid","pop", "country",
                        "state","county", "trait", "unit", "YLD", "MST","ye",'rep_cv','devfromrep', 'devfromcv','w_pen','w_flag')]

colnames(density_all1) = c('YEAR', 'FIPS','LOCYR','TEST_SET_NAME', 'LOC', 'REP_NUMBER', 'ORIGIN', 'PRODUCT_NAME',
                      'HYBRID_PCM_NAME', 'POP', 'COUNTRY', 'STATE', 'COUNTY', 'TRAIT', 'UNIT', 'YIELD','MST',"YE",
                      'rep_cv','devfromrep', 'devfromcv','w_pen','w_flag' )

dat_genv = genv_raw[,c("YEAR","SET_RM","HYBRID_PCM_NAME","POP","OBSERVATION_NAME","TEST_SET_NAME","State","County","FIPS","GEN.Region")]
names(dat_genv) = c("YEAR","SET_RM","HYBRID_PCM_NAME","POP","TRAIT","TEST_SET_NAME",'STATE', 'COUNTY',"FIPS","setgroup")

density_new = merge(density_all1, unique(dat_genv), by=c("YEAR","HYBRID_PCM_NAME","POP","TRAIT","TEST_SET_NAME",'STATE', 'COUNTY',"FIPS"),all.x=T)
density_new = merge(density_new, base_hyb, by.x=c("HYBRID_PCM_NAME"),by.y=c("HYBRID"), all.x = T)

density_new$BASE_HYBRID[is.na(density_new$BASE_HYBRID)] = substr(density_new$HYBRID_PCM_NAME[is.na(density_new$BASE_HYBRID)], 1, 6)

write.csv(density_new, file = paste(output_path, 'DBFlags.csv', sep =''), row.names = F, na ='')


##################################
#     Pre-defined variables      #
##################################

# reasonable range for density
density_all = density_new
pop_vec = sort(unique(density_all$POP))

min_den = pop_vec[1]
max_den = pop_vec[length(pop_vec)]


#given a YE, cost, price,  economical optimal
dl_bu = 3.5
dl_1k = 4


# rm_list = unique(density_all$SET_RM)

####################
#    YLD    part   #
####################
# 
# hybrids = unique(density_all[, c('PRODUCT_NAME','HYBRID_PCM_NAME', 'TEST_SET_NAME')])
# hybrids$HYB_ID = 1:nrow(hybrids)
# num_hybrid = nrow(hybrids)
# 
# density_all = merge(density_all, hybrids, all.x = F, all.y = F)

source("func.R")
# options(warn = 2)#Turn all warnings into error


#output_all = NULL
hybrids_all = NULL

set_list = unique(density_all$TEST_SET_NAME)
  
hybrids = unique(density_all[, c('PRODUCT_NAME','TEST_SET_NAME', 'HYBRID_PCM_NAME')])
hybrids$HYB_ID = 1:nrow(hybrids)
num_hybrid = nrow(hybrids)
  
density_all = merge(density_all, hybrids, all.x = F, all.y = F)
  
  
  
#Calculate means of the products other than the one of interest for YE
ye_mean = NULL
pb1 = txtProgressBar(0, num_hybrid, 0, style = 3)
for (i in 1:num_hybrid){
    
    d_hyb = density_all[density_all$HYB_ID == i,]
    d_nohyb = density_all[density_all$HYB_ID != i,]
    
    mean_temp = aggregate(d_nohyb$YIELD, list(d_nohyb$LOC, d_nohyb$REP_NUMBER), mean)
    colnames(mean_temp) = c('LOC', 'REP_NUMBER', 'LOC_MEAN')
    mean_temp$HYB_ID = i
    
    ye_mean = rbind(ye_mean, mean_temp)
    setTxtProgressBar(pb1, i)
  }
  close(pb1)
  
  density_all = merge(density_all, ye_mean, all.x = F, all.y = F)
  
  min_YE = ceiling(min(ye_mean$LOC_MEAN)/10)*10
  max_YE = ceiling(max(ye_mean$LOC_MEAN)/10)*10
  
  density_all$POP_SQ = density_all$POP^2
  density_all$LOC_MEAN_POP = density_all$LOC_MEAN * density_all$POP
  #density_all$LOC_MEAN_POP_SQ = density_all$LOC_MEAN * density_all$POP_SQ
  
  
  output_all = NULL
  #dataset match product name and ID we defined
  for (j in 1:length(set_list)){
    # for(j in 1:5){
    set_temp = set_list[j]
    print(paste("Working SET", set_temp, ' '))
    
    density = density_all[density_all$TEST_SET_NAME == set_temp, ]
    
    
    var_name = c('YEAR' ,'HYBRID_PCM_NAME', 'LOC', 'REP_NUMBER', 'TEST_SET_NAME', 
                 'PRODUCT_NAME', 'ORIGIN','YIELD', 'POP', 
                 'POP_SQ', 'LOC_MEAN', 'LOC_MEAN_POP',  'HYB_ID')
    
    #Final dataset used for future analysis
    den_response = density[, var_name]
    if(length(unique(den_response$LOC))<3) {next}
    
    ##################################
    #   Modeling and Optimization    #
    ##################################
    
    #initiate a dataframe to store the output
    output_set = NULL
    
    #hybrid list for this set
    hyb_list = sort(unique(den_response$HYB_ID))
    
    print("Calculating Optimal")
    pb = txtProgressBar(0, length(hyb_list),style = 3)
    for (i in hyb_list){
      output = NULL
      t_hyb = i
      
      #filter out data from the particular hybrid
      den_hyb = den_response[which(den_response$HYB_ID == t_hyb),]
      min1 = min(den_hyb$YIELD); max1 = max(den_hyb$YIELD)
      N_LOC = length(unique(den_hyb$LOC))
      N_plot = length(den_hyb$LOC)
      if(N_LOC < 3){next}
      den_hyb$LOC = as.factor(den_hyb$LOC)
      den_hyb$REP_NUMBER = as.factor(den_hyb$REP_NUMBER)
      
      #building the quadratic model: 
      # Y = a + b*POP + c*POP_SQ + d*YE + e*YE*POP
      
      #Full Model
      mod_hyb = lmer(YIELD ~ POP + POP_SQ + LOC_MEAN + LOC_MEAN_POP + (1|LOC), data = den_hyb,
                     REML = T,
                     control = lmerControl(check.scaleX = c("ignore")))
      # cov_reg = vcov(mod_hyb) #covariance matrix of coefficient
      parmt_reg = as.data.frame(t(summary(mod_hyb)$coefficients))
      a = parmt_reg$`(Intercept)`[1]
      b = parmt_reg$POP[1]
      c = parmt_reg$POP_SQ[1]
      d = parmt_reg$LOC_MEAN[1]
      e = parmt_reg$LOC_MEAN_POP[1]
      pval_b = parmt_reg$POP[5]
      pval_c = parmt_reg$POP_SQ[5]
      pval_d = parmt_reg$LOC_MEAN[5]
      pval_e = parmt_reg$LOC_MEAN_POP[5]
      
      #r_2 = as.numeric(r.squaredGLMM(mod_hyb))[2]
      r_2 = 1-var(residuals(mod_hyb))/(var(model.response(model.frame(mod_hyb))))
      adj_r_2 = 1-(1-r_2)*((N_plot-1)/(N_plot-4-1))
      pop_vec = sort(unique(den_hyb$POP))
      
      #simulate data
      sim_locmean = seq(min_YE, max_YE, by = 10) # coeff at all yld environment with diff 10 
      sim_pop = pop_vec
      predsim = expand.grid(sim_locmean, sim_pop )
      colnames(predsim) = c('LOC_MEAN','POP')
      predsim$POP_SQ = predsim$POP ^ 2
      predsim$LOC_MEAN_POP = predsim$LOC_MEAN*predsim$POP
      #predsim$LOC_MEAN_POP_SQ = predsim$LOC_MEAN*predsim$POP_SQ
      predsim$HYBRID_PCM_NAME = hybrids$HYBRID_PCM_NAME[which(hybrids$HYB_ID == t_hyb)]
      
      
      #predictions based on the quadratic model
      # pred_sim = predict(mod_hyb, newdata = predsim, se.fit = T, interval = 'confidence')
      # 
      # pred_fit = as.data.frame(pred_sim$fit)
      # predsim$ESTIMATE = pred_fit$fit
      # predsim$UL_ESTIMATE = pred_fit$upr
      # predsim$LL_ESTIMATE = pred_fit$lwr
      # predsim$STD_ERR = pred_sim$se.fit
      
      predsim$ESTIMATE = a + b*predsim$POP + c*predsim$POP_SQ + d*predsim$LOC_MEAN + e*predsim$LOC_MEAN_POP
      predsim$UL_ESTIMATE = NA
      predsim$LL_ESTIMATE = NA
      predsim$STD_ERR = NA
      
      
      
      #yield optimize
      yield_mat =  as.data.frame(t(sapply(as.vector(predsim$LOC_MEAN), Fun_yld_opt)))
      
      predsim$MAX_YLD = unlist(yield_mat$y)
      predsim$YLD_OPT = unlist(yield_mat$x)
      predsim$SLOPE = unlist(yield_mat$slope)
      predsim$OPT_or_NOT = unlist(yield_mat$opt_not)
      predsim$OPT_RANGE = unlist(yield_mat$range)
      
      
      #eco optimize
      eco_mat = as.data.frame(t(sapply(predsim[,'LOC_MEAN'], function(x) Fun_eco_opt(x, dl_bu, dl_1k))))
      predsim$ECO_YLD = unlist(eco_mat$y)
      predsim$ECO_OPT = unlist(eco_mat$x)
      # predsim$MAX_PROFIT = unlist(eco_mat$profit)
      
      predsim$HD = (predsim$SLOPE>1.5) & (predsim$YLD_OPT-35>3)
      
      #formating output
      var_out = c('HYBRID_PCM_NAME', 'LOC_MEAN', 'POP', 
                  'ESTIMATE',  'LL_ESTIMATE', 'UL_ESTIMATE',
                  'OPT_or_NOT','YLD_OPT', 'MAX_YLD', 
                  'ECO_OPT', 'ECO_YLD', 
                  'SLOPE', 'HD', 'OPT_RANGE')
      output = predsim[,var_out]
      
      colnames(output)[1:2] = c('HYBRID','YE')
      output$TRAIT = 'YLD'
      output$EFFECT = paste(output$HYBRID, output$YE, sep = ':')
      output$a_intcpt = a
      output$b_pop = b
      output$c_pop_sq = c
      output$d_ye = d
      output$e_ye_pop = e
      output$test_pop = pval_b
      output$test_pop_sq = pval_c
      
      output$test_ye = pval_d
      output$test_ye_pop = pval_e
      output$min_yield_level = min1
      output$max_yield_level = max1
      output$R_sq = adj_r_2
      output$site_count = N_LOC
      output$plot_count = N_plot
      output$min_pop = min(pop_vec)
      output$max_pop = max(pop_vec) 
      
      setTxtProgressBar(pb, i)
      
      output_set = rbind(output_set, output)
    }
    close(pb)
    
    output_set$SET_NAME = set_temp
    
    output_all = rbind.fill(output_all, output_set)
    
}
  
output_all$LL_YLD_OPT = ''
output_all$UL_YLD_OPT = ''
output_all$TRAIT = 'YLD'
output_all$ANALYSIS_TYPE = 'CURVE'
output_all$STAGE = 'GENV'
#output_all$YEAR = year
output_all$ModWarning = 'GreenPass'
output_all$ModWarning[output_all$site_count < 5] = 'LowNoLocs'
output_all$ModWarning[output_all$site_count < 5 & output_all$R_sq < 0.6] = 'LowR2&Loc'
output_all$ModWarning[output_all$R_sq < 0.6] = 'LowR2'

dat1 = density_new[,c("YEAR","SET_RM","HYBRID_PCM_NAME","BASE_HYBRID","POP","TRAIT","TEST_SET_NAME","STATE","COUNTY")]
names(dat1) = c("YEAR","SET_RM","HYBRID","Family","POP","TRAIT","SET_NAME","State","County")

output_all = merge(output_all, unique(dat1), by=c("HYBRID","POP","TRAIT","SET_NAME"))

# var_sort = c('STAGE', 'YEAR', 'FIPS','SET_RM','SET_NAME', 'ANALYSIS_TYPE','TRAIT', 'EFFECT', 'HYBRID', 'BASE_HYBRID', 'YE', 'POP',
#              'ESTIMATE', 'UL_ESTIMATE', 'LL_ESTIMATE','a_intcpt', 'b_pop', 'c_pop_sq', 'd_ye', 'e_ye_pop', 'R_sq',
#              'OPT_or_NOT','YLD_OPT' , 'LL_YLD_OPT', 'UL_YLD_OPT', 'MAX_YLD',
#              'ECO_OPT', 'ECO_YLD', 'SLOPE', 'HD', 'OPT_RANGE')
var_sort = c('STAGE', 'YEAR', 'SET_RM','SET_NAME', 'ANALYSIS_TYPE','TRAIT', 'EFFECT', 'HYBRID', 'Family', 'YE', 'POP',
             'ESTIMATE', 'UL_ESTIMATE', 'LL_ESTIMATE','a_intcpt', 'b_pop', 'c_pop_sq', 'd_ye', 'e_ye_pop',"test_pop" , 
             "test_pop_sq","test_ye" , "test_ye_pop", 'R_sq',"site_count", "plot_count", "min_pop","max_pop", "min_yield_level", "max_yield_level" ,
             'ModWarning','OPT_or_NOT','YLD_OPT' , 'LL_YLD_OPT', 'UL_YLD_OPT', 'MAX_YLD',
             'ECO_OPT', 'ECO_YLD', 'SLOPE', 'HD', 'OPT_RANGE')

output_all_test = unique(output_all[,var_sort])
colnames(output_all_test)[colnames(output_all_test) == 'SET_NAME'] = 'TEST_SET_NAME'


# save(output_all, file = './RData/Genv_2015_density.RData')
write.csv(output_all_test, file = paste(output_path, 'Output_sample_density_fips_byHYB.csv', sep =''), row.names = F, na ='')

