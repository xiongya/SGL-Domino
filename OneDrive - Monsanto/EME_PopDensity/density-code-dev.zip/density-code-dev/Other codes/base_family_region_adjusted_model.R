##################
#     Data       #
##################

#loading
rm(list=ls())

# start.time = Sys.time()

my_pcks = c("MASS","lme4","HLMdiag","car","lsmeans","plyr", "MuMIn","lmerTest","data.table")

lapply(my_pcks,require,character.only=TRUE)

set.seed(726)
#Sys.setlocale('LC_ALL','C') 


setwd("C:/work/proj/density_proj")
source("func.R")

#raw data from query
den_raw = read.csv('./Output/DBFlags.csv', stringsAsFactors = F)

# 
# var_mod = c('season', 'FIPS', 'set_rm', 'set', 'field', 'block', 
#             'origin', 'locyr','ye','product_name', 'HYBRID', 
#             'BASE_HYBRID','pop', 'country', 'state', 'county',
#             'trait', 'unit', 'YLD', 'MST',
#             'rep_cv','devfromrep', 'devfromcv','w_pen','w_flag')
# den_raw =den_raw[,var_mod]
# colnames(den_raw) = c('YEAR', 'FIPS','SET_RM','TEST_SET_NAME', 'LOC', 'REP_NUMBER', 'ORIGIN', 'LOCYR','YE','PRODUCT_NAME',
#                       'HYBRID_PCM_NAME', 'family','POP', 'COUNTRY', 'STATE', 'COUNTY', 'TRAIT', 'UNIT', 'YIELD','MST',
#                       'rep_cv','devfromrep', 'devfromcv','w_pen','w_flag' )
# 
# var_mod = c('season', 'FIPS', 'set', 'field', 'block', 'setgroup',
#             'locyr','ye','hybrid', 'base_hybrid','pop',  'state', 'county',
#             'YLD', 'MST', 'rep_cv','devfromrep', 'devfromcv','w_pen','w_flag')

var_mod = c('YEAR', 'SET_RM','TEST_SET_NAME', 'LOC', 'REP_NUMBER','setgroup',  'LOCYR','YE',
                      'HYBRID_PCM_NAME', 'BASE_HYBRID','POP', 'STATE', 'COUNTY', 'YIELD','MST',
                      'rep_cv','devfromrep', 'devfromcv','w_pen','w_flag' )

den_raw =den_raw[,var_mod]
setnames(den_raw,"BASE_HYBRID","family")
density_all = den_raw

##################################
#     Pre-defined variables      #
##################################

#given a YE, cost, price,  economical optimal
dl_bu = 3.5
dl_1k = 4

density_rm = density_all
reg_list = unique(density_rm$setgroup)
family = unique(density_rm[, c('setgroup', 'family')])
family_ID = 1:nrow(family)
family = data.frame(cbind(family,family_ID))
num_family = nrow(family)

density_rm = merge(density_rm, family, all.x = F, all.y = F)



##################################
#   Modeling and Optimization    #
##################################


output_all = NULL
#dataset match product name and ID we defined
for (j in reg_list){
  set_temp = j
  print(paste("Working reg", set_temp, ' '))
  
  density_new = density_rm[density_rm$setgroup == set_temp, ]
  min_YE = ceiling(min(density_new$YE)/10)*10
  max_YE = ceiling(max(density_new$YE)/10)*10
  density_new$POP_SQ = density_new$POP^2
  density_new$YE_POP = density_new$YE * density_new$POP
  
  var_name = c('YEAR' ,'HYBRID_PCM_NAME', 'LOC', 'LOCYR','REP_NUMBER', 'setgroup','TEST_SET_NAME', 
               'YIELD', 'POP', 'POP_SQ', 'YE', 'YE_POP',  'family_ID', 
               'w_pen', 'w_flag')
  
  #Final dataset used for future analysis
  den_response = density_new[, var_name]
  output_set = NULL
  if(length(unique(den_response$LOC))< 3) {next}
  
  ##################################
  #   Modeling and Optimization    #
  ##################################
  
  #initiate a dataframe to store the output
  
  
  #family list for this region
  family_list = sort(unique(den_response$family_ID))
  
  print("Calculating Optimal")
  pb = txtProgressBar(0, length(family_list),style = 3)
  for (i in family_list){
    output = NULL
    t_family = i
    
    #filter out data from the particular hybrid
    den_family = den_response[which(den_response$family_ID == t_family),]
    #print(dim(den_family))
    #ye_mean = aggregate(den_family$YE, list(den_family$family), mean)
    #names(ye_mean) = c("family", "YE_Mean")
    #density_mean = aggregate(den_family$POP, list(den_family$family), mean)
    #names(density_mean) = c( "family", "density_Mean")
    min1 = min(den_family$YE); max1 = max(den_family$YE)
    #min2 = min(density_mean$density_Mean); max2 = max(density_mean$density_Mean)
    
    
    N_LOC = length(unique(den_family$LOC))
    N_plot = length(den_family$LOC)
    if(N_LOC < 3){next}
    den_family$LOCYR = as.factor(den_family$LOCYR)
    den_family$REP_NUMBER = as.factor(den_family$REP_NUMBER)
    
    #building the quadratic model: 
    # Y = a + b*POP + c*POP_SQ + d*YE + e*YE*POP
    
    #Full Model
    mod_family = lmer(YIELD ~ POP + POP_SQ + YE + YE_POP + (1|LOC), data = den_family,
                      REML = T,
                      control = lmerControl(check.scaleX = c("ignore")))
    # cov_reg = vcov(mod_hyb) #covariance matrix of coefficient
    parmt_reg = as.data.frame(t(summary(mod_family)$coefficients))
    a = parmt_reg$`(Intercept)`[1]
    b = parmt_reg$POP[1]
    c = parmt_reg$POP_SQ[1]
    d = parmt_reg$YE[1]
    e = parmt_reg$YE_POP[1]
    pval_b = parmt_reg$POP[5]
    pval_c = parmt_reg$POP_SQ[5]
    pval_d = parmt_reg$YE[5]
    pval_e = parmt_reg$YE_POP[5]
    
    #r_2 = as.numeric(r.squaredGLMM(mod_family))[2]
    r_2 = 1-var(residuals(mod_family))/(var(model.response(model.frame(mod_family))))
    adj_r_2 = 1-(1-r_2)*((N_plot-1)/(N_plot-4-1))
    pop_vec = sort(unique(den_family$POP))
    min_den = pop_vec[1]
    max_den = pop_vec[length(pop_vec)]
    
    #simulate data
    sim_locmean = seq(min_YE, max_YE, by = 10) # coeff at all yld environment with diff 10 
    sim_pop = pop_vec
    predsim = expand.grid(sim_locmean, sim_pop )
    colnames(predsim) = c('LOC_MEAN','POP')
    predsim$POP_SQ = predsim$POP ^ 2
    predsim$LOC_MEAN_POP = predsim$LOC_MEAN*predsim$POP
    #predsim$LOC_MEAN_POP_SQ = predsim$LOC_MEAN*predsim$POP_SQ
    predsim$Family = family$family[which(family$family_ID== t_family)]
    predsim$setgroup =family[which(family$family_ID == t_family),1]
    
    #predictions based on the quadratic model
    # pred_sim = predict(mod_hyb, newdata = predsim, se.fit = T, interval = 'confidence')
    # 
    # pred_fit = as.data.frame(pred_sim$fit)
    # predsim$ESTIMATE = pred_fit$fit
    # predsim$UL_ESTIMATE = pred_fit$upr
    # predsim$LL_ESTIMATE = pred_fit$lwr
    # predsim$STD_ERR = pred_sim$se.fit
    
    predsim$ESTIMATE = a + b*predsim$POP + c*predsim$POP_SQ + d*predsim$LOC_MEAN + e*predsim$LOC_MEAN_POP
    predsim$UL_ESTIMATE = NA
    predsim$LL_ESTIMATE = NA
    predsim$STD_ERR = NA
    
    
    
    #yield optimize
    yield_mat =  as.data.frame(t(sapply(as.vector(predsim$LOC_MEAN), Fun_yld_opt)))
    
    predsim$MAX_YLD = unlist(yield_mat$y)
    predsim$YLD_OPT = unlist(yield_mat$x)
    predsim$SLOPE = unlist(yield_mat$slope)
    predsim$OPT_or_NOT = unlist(yield_mat$opt_not)
    predsim$OPT_RANGE = unlist(yield_mat$range)
    
    
    #eco optimize
    eco_mat = as.data.frame(t(sapply(predsim[,'LOC_MEAN'], function(x) Fun_eco_opt(x, dl_bu, dl_1k))))
    predsim$ECO_YLD = unlist(eco_mat$y)
    predsim$ECO_OPT = unlist(eco_mat$x)
    # predsim$MAX_PROFIT = unlist(eco_mat$profit)
    
    predsim$HD = (predsim$SLOPE>1.5) & (predsim$YLD_OPT-35>3)
    
    #formating output
    var_out = c('setgroup','Family', 'LOC_MEAN', 'POP', 
                'ESTIMATE',  'LL_ESTIMATE', 'UL_ESTIMATE',
                'OPT_or_NOT','YLD_OPT', 'MAX_YLD', 
                'ECO_OPT', 'ECO_YLD', 
                'SLOPE', 'HD', 'OPT_RANGE')
    output = predsim[,var_out]
    #formating output
    #output = data.frame(family[which(family$family_ID == t_family),1:2])
    colnames(output)[1:3] = c("SetGroup","Family","YE")
    output$TRAIT = 'YLD'
    #output$EFFECT = paste(output$Family, output$YE, sep = ':')
    output$a_intcpt = a
    output$b_pop = b
    output$c_pop_sq = c
    output$d_ye = d
    output$e_ye_pop = e
    output$test_pop = pval_b
    output$test_pop_sq = pval_c
    output$test_ye = pval_d
    output$test_ye_pop = pval_e
    output$min_yield_level = min1
    output$max_yield_level = max1
    output$R_sq = adj_r_2
    output$site_count = N_LOC
    output$plot_count = N_plot
    output$min_pop = min(pop_vec)
    output$max_pop = max(pop_vec) 
    
    
    setTxtProgressBar(pb, i)
    
    #output_set = rbind(output_set, output)
    output_set = rbind.fill(output_set, output)
    #print(i)    
  }
  close(pb)
  output_all = rbind(output_all, output_set)
}


output_all$LL_YLD_OPT = ''
output_all$UL_YLD_OPT = ''
output_all$TRAIT = 'YLD'
output_all$ANALYSIS_TYPE = 'CURVE'
output_all$STAGE = 'GENV'
#output_all$min_pop = min(pop_vec)
#output_all$max_pop = max(pop_vec) 
output_all$ModWarning = 'GreenPass'
output_all$ModWarning[output_all$site_count < 5] = 'LowNoLocs'
output_all$ModWarning[output_all$site_count < 5 & output_all$R_sq < 0.6] = 'LowR2&Loc'
output_all$ModWarning[output_all$R_sq < 0.6] = 'LowR2'
output_all=output_all[order(output_all$Family),]


dat1 = den_raw[,c("YEAR",'SET_RM',"TEST_SET_NAME","HYBRID_PCM_NAME","POP","family","setgroup")]
names(dat1) = c("YEAR",'SET_RM',"SET_NAME","HYBRID","POP","Family","SetGroup")

output_all_new = merge(output_all, unique(dat1), by=c("Family","SetGroup","POP"),all.x=T)


var_sort = c('STAGE', 'YEAR', 'SET_RM', 'SET_NAME', 'ANALYSIS_TYPE','TRAIT', 'HYBRID', 'Family',"SetGroup", 'POP',
             'ESTIMATE', 'UL_ESTIMATE', 'LL_ESTIMATE','a_intcpt', 'b_pop', 'c_pop_sq', 'd_ye', 'e_ye_pop',"test_pop" , 
             "test_pop_sq", "test_ye" , "test_ye_pop",'R_sq',"site_count", "plot_count", "min_pop","max_pop", "min_yield_level", "max_yield_level" ,
             'ModWarning','OPT_or_NOT','YLD_OPT' , 'LL_YLD_OPT', 'UL_YLD_OPT', 'MAX_YLD',
             'ECO_OPT', 'ECO_YLD', 'SLOPE', 'HD', 'OPT_RANGE', 'YE')
output_all_test = output_all_new[,var_sort]

output_path = './Output/'
write.csv(output_all_test, file = paste(output_path, 'sample_data_adjusted_Region_Family.csv', sep =''), row.names = F, na ='')
